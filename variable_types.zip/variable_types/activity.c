#include <stdio.h>

int main() {
	
	printf("\n\n");
	
	int age = 22;
	printf("Age : %d \n\n" , age);
	
	float dec = 15;
	printf("Decimal : %.2f \n\n" , dec);
	
	double num = 10;
	printf("Number : %.21f \n\n" , num);
	
	char c = 'A';
	printf("Character : %x \n\n" , c);
	
	char name[] = "Anpu";
	printf("Name : %s \n\n" , name);
	
	printf("Name : %c \n\n" , name[2]);
	
	
	return 0;
}