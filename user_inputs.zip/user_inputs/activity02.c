#include <stdio.h>

int main() {
	
	int age;
	char name[50];

	printf("\n Enter your name : "); //Output
	scanf("%s", name);
	
	printf("\n Enter your age : "); //Output
	scanf("%d", &age); /*Input (Get the value from the user)
						(&) is used here to pass the 
						memory address of the variable to scanf*/

	
	printf("\n User name is : %s \n\n", name);
	printf("\n Age is : %d \n\n", age);
	
	
	return 0;
}